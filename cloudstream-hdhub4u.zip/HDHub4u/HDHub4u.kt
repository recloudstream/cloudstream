class HDHub4u : MainAPI() {
    override var mainUrl = "https://hdhub4u.gratis"
    override var name = "HDHub4u"
    override val hasMainPage = true
    override var lang = "en"
    override val supportedTypes = setOf(TvType.Movie)

    override val mainPage = listOf(
        MainPageData("$mainUrl/category/bollywood/", "Bollywood", true),
        MainPageData("$mainUrl/category/dual-audio/", "Dual Audio", true)
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val doc = app.get(request.data).document
        val items = doc.select("article").mapNotNull {
            val href = it.selectFirst("a")?.attr("href") ?: return@mapNotNull null
            val title = it.selectFirst("h2")?.text() ?: return@mapNotNull null
            val image = it.selectFirst("img")?.attr("src")
            newMovieSearchResponse(title, href, TvType.Movie) {
                this.posterUrl = image
            }
        }
        return newHomePageResponse(request.name, items)
    }

    override suspend fun load(url: String): LoadResponse {
        val doc = app.get(url).document
        val title = doc.selectFirst("h1")?.text() ?: return errorLoadResponse()
        val iframe = doc.select("iframe[src]").attr("src")
        return newMovieLoadResponse(title, url, TvType.Movie, iframe) {
            this.posterUrl = null
        }
    }
}